CREATE TABLE calls(
	`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`caller` varchar(150) NOT NULL,
	`caller_name`   varchar(150) NOT NULL,
	`call_time` int(12) NOT NULL,
	PRIMARY KEY (`id`)
);
