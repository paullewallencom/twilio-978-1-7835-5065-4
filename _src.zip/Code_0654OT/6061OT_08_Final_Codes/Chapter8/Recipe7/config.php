<?php

define("SF_USERNAME", "");
define("SF_PASSWORD", "");
define("SF_SECURITY_TOKEN", "");

$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM