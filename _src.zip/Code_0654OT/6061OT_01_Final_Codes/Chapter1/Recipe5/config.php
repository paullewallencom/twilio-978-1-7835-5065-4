<?php
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM
	$toNumber = '';		//	YOUR PHONE NUMBER TO CALL
	$toEmail = '';		//	YOUR EMAIL TO EMAIL YOU THE RECORDING
?>
