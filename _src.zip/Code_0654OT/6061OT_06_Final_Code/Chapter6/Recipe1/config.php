<?php
	session_start();
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM

?>
