<h2>Sign up</h2>
<form class="form-horizontal" action="<?=$uri?>/signup" method="POST">
<table>
<tr>
	<td>Your Name</td>
	<td><input type="text" name="name" /></td>
</tr>
<tr>
	<td>Your Email</td>
	<td><input type="text" name="email" /></td>
</tr>
<tr>
	<td>Your Password</td>
	<td><input type="text" name="password" /></td>
</tr>
<tr>
	<td>Your Phone Number</td>
	<td><input type="text" name="phone_number" /></td>
</tr>
</table>
<button type="submit">Sign up</button>
</form>