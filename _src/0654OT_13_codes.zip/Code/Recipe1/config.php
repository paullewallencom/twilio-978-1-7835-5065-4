<?php
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$appsid = '';	//	YOUR TWILIO APP SID
?>
