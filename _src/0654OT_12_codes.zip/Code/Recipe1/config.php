<?php
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$callqueue = 'Twilio Cookbook'; //	YOUR CALL QUEUE
?>
