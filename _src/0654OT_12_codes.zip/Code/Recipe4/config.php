<?php
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$callqueue = 'Twilio Cookbook'; //	YOUR CALL QUEUE
	$callqueue_sid = 'QU73dd3cc19e0149658c484a7064a186e1'; //	YOUR CALL QUEUE SID	
	$toNumber = '' // YOUR PHONE NUMBER TO CALL
?>
