<?php
	$accountsid = '';	//	YOUR TWILIO ACCOUNT SID
	$authtoken = '';	//	YOUR TWILIO AUTH TOKEN
	$fromNumber = '';	//	PHONE NUMBER CALLS WILL COME FROM
	$myUrl = '';	//	THE URL TO YOUR PHOTO GALLERY
	
	$blacklist = array(
		'7894561230'
	);
	$whitelist = array(
		'2045697890','4041234567'
	);	

	$dbhost = '';	//	YOUR DATABASE HOST
	$dbname = '';	//	YOUR DATABASE NAME
	$dbuser = '';	//	YOUR DATABASE USER
	$dbpass = '';	//	YOUR DATABASE PASS
?>
